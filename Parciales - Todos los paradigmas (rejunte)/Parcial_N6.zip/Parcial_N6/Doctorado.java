
package Parcial_N6;


public class Doctorado extends Alumno {
    private String titulo;
    private String universidad;
    
//------------------------------------------------------------------------------   
    
    public Doctorado (int DNI, String nombreAlumno, String titulo, String universidad){
        super(DNI,nombreAlumno);
        this.titulo = titulo;
        this.universidad = universidad;
    }
 
//------------------------------------------------------------------------------    

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getUniversidad() {
        return universidad;
    }

    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }
    
//------------------------------------------------------------------------------   

    public String toString(){
        String acumulador=" ";
        for (int i=0; i<this.getCantMaterias(); i++){
            acumulador += this.retornarMaterias(i)+" ";
        }
        return "DNI: "+this.getDNI()+" Nombre "+this.getNombreAlumno()+" Materias: "+acumulador+" Esta graduado: "+this.gradudado()+" Titulo: "+this.getTitulo()+" Universidad: "+this.universidad;
    }
    
    
}
