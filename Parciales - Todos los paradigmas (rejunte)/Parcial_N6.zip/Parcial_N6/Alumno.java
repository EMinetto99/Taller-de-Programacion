
package Parcial_N6;


public abstract class Alumno {
    private int DNI;
    private String nombreAlumno;
    private Materia [] materias;
    private int cantMaterias;
    
    
//------------------------------------------------------------------------------

    public Alumno (int DNI, String nombreAlumno){
        this.DNI = DNI;
        this.nombreAlumno = nombreAlumno;
        this.cantMaterias = 0;
        this.materias = new Materia[5];
        
        for (int i=0; i<cantMaterias; i++){
            this.materias[i]=null;
        }
    }
    
//------------------------------------------------------------------------------       

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }

    public int getCantMaterias() {
        return cantMaterias;
    }

    public void setCantMaterias(int cantMaterias) {
        this.cantMaterias = cantMaterias;
    }
    
    
//------------------------------------------------------------------------------   

    public void agregarMateria (Materia materia){
        this.materias[this.cantMaterias] = materia;
        this.cantMaterias++;
    }
    
    public boolean gradudado (){
        for (int i=0; i<this.cantMaterias; i++){
            if(this.materias[i].getNombre().equals("Tesis")){
               if(this.cantMaterias == 5){
                   return true;
               }
            }
        }
        return false;
    }
    
    public String retornarMaterias (int numeroMateria){
        return this.materias[numeroMateria].getNombre()+" "+this.materias[numeroMateria].getNota()+" "+this.materias[numeroMateria].getFecha();
    }
    
    public abstract String toString();
    
}
