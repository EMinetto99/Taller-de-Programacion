
package Parcial_N6;


public class ProgramaPPL {

    
    public static void main(String[] args) {
        Grado grado = new Grado(1234,"joaquina","Informatica");
        Doctorado doctorado = new Doctorado(2345,"Ramiro","Artista Platsico","UNLP");
        
        Materia mat1 = new Materia("Quimica",10,"20/4/2021");
        Materia mat2 = new Materia("Fisica",10,"20/4/2021");
        Materia mat3 = new Materia("Programacion",9,"20/4/2021");
        
        Materia mat5 = new Materia("Dibujo",3,"20/4/2021");
        Materia mat6 = new Materia("Arte",5,"20/4/2021");
        Materia mat7 = new Materia("Pntura",9,"20/4/2021");
        Materia mat8 = new Materia("Hola",10,"20/4/2021");
        Materia mat9 = new Materia("Tesis",8,"20/4/2021");
        
        grado.agregarMateria(mat1);
        grado.agregarMateria(mat2);
        grado.agregarMateria(mat3);
        
        
        doctorado.agregarMateria(mat5);
        doctorado.agregarMateria(mat6);
        doctorado.agregarMateria(mat7);
        doctorado.agregarMateria(mat8);
        doctorado.agregarMateria(mat9);
        
        System.out.println(grado.toString());
        System.out.println(doctorado.toString());
    }
    
}
