
package Parcial_N6;


public class Grado extends Alumno{
    private String carrera;
    
//------------------------------------------------------------------------------   
    
    public Grado (int DNI, String nombreAlumno, String carrera){
        super(DNI,nombreAlumno);
        this.carrera = carrera;
    }
    
 //------------------------------------------------------------------------------   

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
    
//------------------------------------------------------------------------------   
    
    
    public String toString(){
        String acumulador=" ";
        for (int i=0; i<this.getCantMaterias(); i++){
            acumulador += this.retornarMaterias(i)+" ";
        }
        return "DNI: "+this.getDNI()+" Nombre "+this.getNombreAlumno()+" Materias: "+acumulador+" Esta graduado: "+this.gradudado()+" Carrera: "+this.getCarrera();
    }
    
}
